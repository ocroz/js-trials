var lunrData = [{"id":99455474,"title":"Training Git Total","link":"Training_Git_Total.html"}];
